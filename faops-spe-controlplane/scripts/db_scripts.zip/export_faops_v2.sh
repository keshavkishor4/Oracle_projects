#!/bin/bash

source $HOME/.bash_profile
#Variables used in the script
DATE=$(date +'%Y%m%d_%H%M%S')
HOSTNAME=$(hostname -f)
PDB_NAME=apexpdb
SERVICENAME=$(lsnrctl status |grep -i ${PDB_NAME} | awk '{print $2}'|sed 's/"//g')
EXP_BASE_DIR='/u01/app/oracle/expdir'
LOGFILE=faops_export_${DATE}.log
CATALOG_URL="https://catalogdb-dev-oci.falcm.ocs.oc-test.com"

function pre_tasks() {
  # Creating Export Directory
  if [ -d "/u01/app/oracle/expdir" ]
  then
      echo "Directory $EXP_BASE_DIR already exists." | tee ${EXP_BASE_DIR}/${LOGFILE}
  else
      echo "Creating directory $EXP_BASE_DIR"
      mkdir -p $EXP_BASE_DIR
  fi
  # Verify if the parameter file exists
  echo "Verifying parameter file" | tee ${EXP_BASE_DIR}/${LOGFILE}
  if [ -f "/u01/app/oracle/expdir/faops_exp.par" ]
  then
      echo "Parameter file faops_exp.par already exists." | tee ${EXP_BASE_DIR}/${LOGFILE}
  else
      echo "Creating parameter file faops_exp.par" | tee ${EXP_BASE_DIR}/${LOGFILE}
      echo -e "directory=faops_exp \ndumpfile=faops_exp%U.dmp \nlogfile=faops_exp.log \nschemas=faops \ncontent=all \nEXCLUDE=STATISTICS \nexclude=table:\"like 'BIN$%'\" \nexclude=sequence:\"like 'BIN$%'\" \nexclude=view:\"like 'BIN$%'\" \nexclude=type:\"like 'BIN$%'\" \nCLUSTER=N \nparallel=8 " > ${EXP_BASE_DIR}/faops_exp.par
  fi

  # Verifying if export log exists and back it up
  echo "Verifying if old export log file exists and backing it up" | tee ${EXP_BASE_DIR}/${LOGFILE}
  if [ -f "/u01/app/oracle/expdir/faops_exp.log" ]
  then
      echo "Log file faops_exp.log exists, renaming it." | tee ${EXP_BASE_DIR}/${LOGFILE}
      mv /u01/app/oracle/expdir/faops_exp.log /u01/app/oracle/expdir/faops_exp_${DATE}.log
  fi
}

function db_tasks() {
  #Create a temporary account, directory and execute export of the FAOPS schema
  echo "Performing DB tasks, creating a new user, grant privs and create directory" | tee ${EXP_BASE_DIR}/${LOGFILE}
  sqlplus -s / as sysdba << EOF
  spool  /u01/app/oracle/expdir/database.log
  alter session set container=${PDB_NAME};
  create user upguser identified by upguser default tablespace faopscbdb quota unlimited on faopscbdb;
  grant connect,resource to upguser;
  alter user upguser account unlock;
  grant dba to upguser;
  create or replace directory faops_exp as '/u01/app/oracle/expdir';
  spool off
EOF

  echo "Changing directory to /tmp/expdir" | tee ${EXP_BASE_DIR}/${LOGFILE}
  cd  $EXP_BASE_DIR

  echo "Running Export of FAOPS schema" | tee ${EXP_BASE_DIR}/${LOGFILE}
  expdp userid=upguser/upguser@//$HOSTNAME/$SERVICENAME parfile=faops_exp.par
}

function post_tasks() {
  # Verify if there were any errors in the log else drop the temporary user
  ORA_ERR="$(grep ORA- $EXP_BASE_DIR/faops_exp.log |wc -l)"
  if [ "$ORA_ERR" != "0" ]
    then
        echo "Errors found in log faops_exp.log, ending this session" | tee ${EXP_BASE_DIR}/${LOGFILE}
        exit 1
      else
        echo "No errors found. Dropping the upguser from database" | tee ${EXP_BASE_DIR}/${LOGFILE}
        sqlplus -s / as sysdba << EOF
        alter session set container=${PDB_NAME};
        drop user upguser;
EOF
  fi
}

function upload() {
  #Upload the log and dump files to the OSS.
  local IS_DEV=$(hostname -d|grep -ic "dev")
  local IS_PPD=$(hostname -d|grep -ic "ppd")
  local CURLTO=10

  REGION=$(curl -m ${CURLTO} -L http://169.254.169.254/opc/v1/instance/canonicalRegionName 2>/dev/null)

  if [ "X$REGION" != "X" ]
    then
      if [ $IS_DEV -eq 1 ] ; then
        FILE_NAME="DEV-${REGION}";
      elif [ $IS_PPD -eq 1 ] ; then
        FILE_NAME="PPD-${REGION}";
      else
        FILE_NAME="PRD-${REGION}";
      fi
  else
    echo "unknown_catalogdb" | tee ${EXP_BASE_DIR}/${LOGFILE}
    return 1
  fi

  echo "Zipping dump, pararameter and log files" | tee ${EXP_BASE_DIR}/${LOGFILE}
  cd $EXP_BASE_DIR

  zip ${FILE_NAME}_PAR_LOG.zip faops_exp.log faops_exp.par
  zip ${FILE_NAME}_DMP.zip *.dmp

  OUTCODE=$(curl -k --progress-bar --connect-timeout 30 --retry 3 --retry-delay 5 -H "Authorization:Basic ZmFvcHNjYjpGQTBuMENJMjAyMCM=" -w "%{http_code}"  -F "file_name=@${EXP_BASE_DIR}/${FILE_NAME}_DMP.zip" "$CATALOG_URL/ords/ocibakrev/uploadlocal/?file=${FILE_NAME}_DMP.zip")
  if [ "$OUTCODE" == "${FILE_NAME}_DMP.zip200" ]; then
    echo "Successfully uploaded Dump files" | tee ${EXP_BASE_DIR}/${LOGFILE}
  else
    echo "Upload of dump files failed" | tee ${EXP_BASE_DIR}/${LOGFILE}
  fi
  OUTCODE=$(curl -k --progress-bar --connect-timeout 30 --retry 3 --retry-delay 5 -H "Authorization:Basic ZmFvcHNjYjpGQTBuMENJMjAyMCM=" -w "%{http_code}"  -F "file_name=@${EXP_BASE_DIR}/${FILE_NAME}_PAR_LOG.zip" "$CATALOG_URL/ords/ocibakrev/uploadlocal/?file=${FILE_NAME}_PAR_LOG.zip")
  if [ "$OUTCODE" == "${FILE_NAME}_PAR_LOG.zip200" ]; then
    echo "Successfully uploaded Par & Log files" | tee ${EXP_BASE_DIR}/${LOGFILE}
  else
    echo "Upload of Par & Log files failed" | tee ${EXP_BASE_DIR}/${LOGFILE}
  fi
}

echo "Exporting FAOPS schema from the catalogdb"
echo "Performing the pre-check tasks" 
pre_tasks
echo "Performing the db tasks" | tee ${EXP_BASE_DIR}/${LOGFILE}
db_tasks
echo "Performing the post-check tasks" | tee ${EXP_BASE_DIR}/${LOGFILE}
post_tasks
echo "Uploading the exported data to OSS" | tee ${EXP_BASE_DIR}/${LOGFILE}
upload